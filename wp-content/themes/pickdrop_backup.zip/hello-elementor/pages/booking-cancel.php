<?php

/*
    Template Name: Booking Cancel
*/

wp_redirect(home_url());
redirect_js(home_url());
wp_die();